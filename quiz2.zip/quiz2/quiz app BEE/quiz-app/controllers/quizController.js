const questions = [
    { id: 1, question: "What is Node.js?", options: ["Language", "Runtime", "Library"], answer: "Runtime" },
    { id: 2, question: "Which framework is used with Node.js?", options: ["Django", "Flask", "Express"], answer: "Express" },
    { id: 3, question: "Which module is used to create a server in Node.js?", options: ["http", "fs", "path"], answer: "http" },
    { id: 4, question: "Which of the following is NOT a Node.js package manager?", options: ["npm", "yarn", "pip"], answer: "pip" },
    { id: 5, question: "What is the default scope in Node.js?", options: ["Global", "Function", "Module"], answer: "Module" }
];

