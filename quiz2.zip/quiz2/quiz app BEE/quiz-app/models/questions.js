// const questions = [
//     { id: 1, question: "What is Node.js?", options: ["Language", "Runtime", "Library"], answer: "Runtime" },
//     { id: 2, question: "Which framework is commonly used with Node.js?", options: ["Django", "Flask", "Express"], answer: "Express" },
//     { id: 3, question: "Which module is used to create a server in Node.js?", options: ["http", "fs", "path"], answer: "http" },
//     { id: 4, question: "What does npm stand for?", options: ["Node Package Manager", "Network Protocol Module", "New Programming Method"], answer: "Node Package Manager" },
//     { id: 5, question: "Which method is used to handle HTTP requests in Express?", options: ["fetch()", "app.get()", "http.request()"], answer: "app.get()" }
// ];

// module.exports = questions;
