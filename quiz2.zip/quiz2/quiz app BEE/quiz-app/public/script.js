let currentQuestionIndex = 0;
let questions = [];

document.addEventListener("DOMContentLoaded", () => {
    fetchQuestions();
    document.getElementById("next-btn").addEventListener("click", nextQuestion);
});

function fetchQuestions() {
    fetch("http://localhost:3000/quiz/questions")
        .then(response => response.json())
        .then(data => {
            questions = data;
            displayQuestion();
        })
        .catch(error => console.error("Error fetching questions:", error));
}

function displayQuestion() {
    const container = document.getElementById("question-container");
    container.innerHTML = "";

    if (currentQuestionIndex >= questions.length) {
        container.innerHTML = "<h2>Quiz Completed! 🎉</h2>";
        document.getElementById("next-btn").style.display = "none";
        return;
    }

    let question = questions[currentQuestionIndex];
    container.innerHTML = `<h2>${question.question}</h2>`;

    question.options.forEach(option => {
        let btn = document.createElement("button");
        btn.textContent = option;
        btn.onclick = () => checkAnswer(option, question.answer);
        container.appendChild(btn);
    });
}

function checkAnswer(selected, correct) {
    const result = document.getElementById("result");
    if (selected === correct) {
        result.textContent = "Correct! 🎉";
        result.style.color = "green";
    } else {
        result.textContent = "Wrong! ❌";
        result.style.color = "red";
    }
}

function nextQuestion() {
    currentQuestionIndex++;
    document.getElementById("result").textContent = "";
    displayQuestion();
}

function addNewQuestion() {
    const newQuestion = {
        question: "What is the capital of India?",
        options: ["Delhi", "Mumbai", "Kolkata"],
        answer: "Delhi"
    };

    fetch("http://localhost:3000/quiz/questions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newQuestion)
    })
    .then(response => response.json())
    .then(data => {
        console.log("New question added:", data);
        fetchQuestions();  // Refresh quiz questions
    })
    .catch(error => console.error("Error adding question:", error));
}


